package Modelo;


public class Autentificacion {
    public static boolean autenticar(String usuario, String password){
        if(usuario.equals("Milton")&& password.equals("contra123")){
         return true;   
        }else{
            return false;
        }
    }
}
